INSERT INTO alumnos (id, nombre, apellido) VALUES (1, "Cristian", "Varela"), (2, "Maksym", "Kazantsev"), (3, "Pablo", "Navarro"), (4, "Mateo", "Gómez"), (5, "Iván", "Beliño");
INSERT INTO bares (id, nombre) VALUES (1, "Daydos"), (2, "Manix"), (3, "Penela"), (4, "Capitol");
INSERT INTO camareros (id, nombre, apellido) VALUES (1, "Jenny", "del Daydos"), (2, "Lupita", "Villa"), (3, "Lucera", "del Monte"), (4, "Pedro", "del Río");
INSERT INTO grupos (id, nombre) VALUES (1, "Macacos del Web"), (2, "Furros Backend"), (3, "Html Frontends");
INSERT INTO productos (id, nombre, precio) VALUES (1, "café con leche", 1.2), (2, "cortado", 1), (3, "cerveza", 2.1), (4, "coca cola", 1.8), (5, "té", 1.5), (6, "agua", 1), (7, "cruasán", 0.9), (8, "bocadillo", 1.6), (9, "napolitana", 1.1), (10, "hamburguesa", 4.5), (11, "pizza", 9), (12, "gin tonic", 6);
